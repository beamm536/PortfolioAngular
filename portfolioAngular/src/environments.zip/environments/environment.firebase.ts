export const firebaseConfig = {
    apiKey: "AIzaSyC1bT_rpQrlFSktVU7RlimbbPCC2xPCwpc",
    authDomain: "intermodular-26c92.firebaseapp.com",
    projectId: "intermodular-26c92",
    storageBucket: "intermodular-26c92.firebasestorage.app",
    messagingSenderId: "508747488825",
    appId: "1:508747488825:web:1359b1cdfb4c67211937e8"
  };